
cd $envvar
cd sources/main
./main