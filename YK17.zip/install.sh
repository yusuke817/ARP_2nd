#!/bin/bash
pwd=$(pwd)
chmod +x ./run.sh
unzip -d $1 sources.zip
cd $1
export envvar=$1

gcc -o ./exec/sources/unnamed/unnamed ./exec/sources/unnamed/unnamed.c
chmod +x ./exec/sources/unnamed/unnamed
gcc -o ./exec/sources/named/named ./exec/sources/named/named
chmod +x ./exec/sources/named/named
gcc -o ./exec/sources/socket/socket ./exec/sources/socket/socket
chmod +x ./exec/sources/socket/socket
gcc -pthread -o ./exec/sources/shared/shared ./exec/sources/shared/shared
chmod +x ./exec/sources/shared/shared

cd $pwd
