more readme.txt
