
cd $envvar
cd sources/Main
./main