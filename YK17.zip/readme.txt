<General information on the authors of this assignment>
The name of the group is YK17. The member is Yusuke(5239225).

<The purpose of this assignment>
	I implemented four kinds of programs to measure the speed efficiency when transferring data between a producer and a consumer using different models. The four programs transmit the data with unnamed pipe, named pipe, socket and shared memory with circular buffer.

<The contents of the package>
	This package is composed of three bash file (install, run.sh and help.sh) , readme.txt and four 
source files.The source files are unnamed.c, named.c, socket.c and shared.c.

<How to execute the program>

1) Execute ". ./install.sh ./exec" in main konsole which enables you to unzip and compile all of 
	the files.

2) Execute "./help.sh" in main konsole to get the explanation of this program. If you don't have 
	permission, you should input "chmod +x help.sh." 

3) Execute "./run.sh" in main konsole which enables you to run this program and select the method you want to try.

<How to>
After selecting the method, you can set the bytes of data and get the transmitting time.

A. Transmitting the data with unnamed pipe, named pipe and socket.

1) After the instruction of "Please input the bytes of transmitted data", you can decide any bytes of transmitted data less than 100 MB.

2) You can get the transmitting time. "wall (passed) time in execution : (transmitting time)"

B. Transmitting the data with shared memory with circular buffer.

1) After the instruction of "Please input the bytes of transmitted data", you can decide any bytes of transmitted data less than 100 MB.

2) After the instruction of "Please input the size of circular buffer which should be equal or smaller than the bytes of transmitted data", you can decide any bytes of transmitted data equal or less than the bytes of transmitted data.

3) You can get the transmitting time. "wall (passed) time in execution : (transmitting time)"

<Result>
The four wall (passed) times in execution were almost same. When the bytes of data transmitted was 10MB, each of the times was shown below.

1) unnamed.c -- 0.22435 sec

2) named.c -- 0.22080 sec

3) socket.c -- 0.22093 sec

4) shared.c -- 0.25808 sec